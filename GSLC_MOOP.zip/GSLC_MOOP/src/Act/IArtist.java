package Act;

public interface IArtist {

	void Paint();

}
