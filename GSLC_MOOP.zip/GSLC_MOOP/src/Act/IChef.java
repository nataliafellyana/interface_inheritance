package Act;

public interface IChef {
	
	void Cook();
}
