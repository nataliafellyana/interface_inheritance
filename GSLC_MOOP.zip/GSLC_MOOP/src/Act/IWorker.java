package Act;

public interface IWorker {

	void Work();

}
