package Act;

public interface IDriver {

	void Drive();

}
