import java.util.ArrayList;
import java.util.Scanner;

import Act.IArtist;
import Act.IChef;
import Act.IDriver;
import Act.IWorker;

import java.util.*;

public class Main {

	ArrayList <BaseCharacter> karakter = new ArrayList<>();
	Scanner scan = new Scanner(System.in);
	
	String nama, deskripsi;
	String choice;
	
	public Main(){
		
		BaseCharacter chef= new Chef ("Chef" , ", cooks at the restaurant.");
		BaseCharacter driver=new Driver("Driver" , ", drives with a car / motorcycle.");
		BaseCharacter worker=new Worker("Worker" , ", works at the office.");
		BaseCharacter artist=new Artist("Artist" , ", paints many pictures.");
		BaseCharacter multi=new Multitalent("Multitalent" , ", can do all the jobs.");
		BaseCharacter untalent=new Untalent("Untalent" , ", can not do anything.");
		
		karakter.add(chef);
		karakter.add(driver);
		karakter.add(worker);
		karakter.add(artist);
		karakter.add(multi);
		karakter.add(untalent);
		
		System.out.println("The Ability Simulation");
		System.out.println("======================");
		System.out.println("0. Chef");
		System.out.println("1. Driver");
		System.out.println("2. Worker");
		System.out.println("3. Artist");
		System.out.println("4. Multitalent");
		System.out.println("5. Untalent");
		do{
			System.out.print("Input [Info|Cook|Drive|Work|Paint] and I: ");
			choice = scan.nextLine();
		}while(!choice.contains("Info") && !choice.contains("Cook") && !choice.contains("Drive") && !choice.contains("Work") && !choice.contains("Paint"));
		
		String charAct = choice.substring(0, choice.indexOf(" "));
		String charID = choice.substring(choice.indexOf(" ")+1);
		
		for(int i=0 ; i<charID.length() ; i=i+2){
			Integer id = Integer.parseInt(charID.substring(i, i+1));
			switch(charAct){
				case "Info":
					karakter.get(id).getInfo();
					break;
				case "Cook":
					if(karakter.get(id) instanceof IChef){
						((IChef)karakter.get(id)).Cook();
					}
					else
					{
						System.out.println(karakter.get(id).getNama() + " can not cook.");
					}
					break;
				case "Drive":
					if(karakter.get(id) instanceof IDriver){
						((IDriver)karakter.get(id)).Drive();
					}
					else
					{
						System.out.println(karakter.get(id).getNama() + " can not drive.");
					}
					break;
				case "Work":
					if(karakter.get(id) instanceof IWorker){
						((IWorker)karakter.get(id)).Work();
					}
					else
					{
						System.out.println(karakter.get(id).getNama() + " can not work.");
					}
					break;
				case "Paint":
					if(karakter.get(id) instanceof IArtist){
						((IArtist)karakter.get(id)).Paint();
					}
					else
					{
						System.out.println(karakter.get(id).getNama() + " can not paint.");
					}
					break;
			}
		}
		
		
	}
	

	public static void main(String[] args) {
		new Main();
	}

}
