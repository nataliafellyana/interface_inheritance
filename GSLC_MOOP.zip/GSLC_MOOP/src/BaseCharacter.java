

public class BaseCharacter {
	
	private String nama;
	private String deskripsi;
	
	public BaseCharacter(String nama, String deskripsi) {
		// TODO Auto-generated constructor stub
		this.nama=nama;
		this.deskripsi=deskripsi;
	}
	
	public String getNama() {
		return nama;
	}

	public void setNama(String nama) {
		this.nama = nama;
	}
	
	public String getDeskripsi(){
		return deskripsi;
	}
	
	public void setDeskripsi(String deskripsi){
		this.deskripsi=deskripsi;
	}

	public void getInfo(){
		System.out.println(this.getNama() + this.deskripsi);
	}

}
