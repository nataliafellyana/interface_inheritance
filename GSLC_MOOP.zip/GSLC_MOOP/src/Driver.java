
import Act.IDriver;
import Act.IWorker;

public class Driver extends BaseCharacter implements IDriver, IWorker{

	public Driver(String nama, String deskripsi) {
		super(nama, deskripsi);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void Drive() {
		// TODO Auto-generated method stub
		System.out.println(getNama() + " can drive.");
	}

	@Override
	public void Work() {
		// TODO Auto-generated method stub
		System.out.println(getNama() + " can work.");
	}

	

}
