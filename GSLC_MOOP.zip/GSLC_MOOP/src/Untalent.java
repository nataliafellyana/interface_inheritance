

public class Untalent extends BaseCharacter{

	public Untalent(String nama, String deskripsi) {
		super(nama, deskripsi);
		// TODO Auto-generated constructor stub
	}

}
