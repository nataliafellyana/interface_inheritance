
import Act.IChef;

public class Chef extends BaseCharacter implements IChef{

	public Chef(String nama, String deskripsi) {
		super(nama, deskripsi);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void Cook() {
		// TODO Auto-generated method stub
		System.out.println(getNama() + " can cook.");
	}

}
