
import Act.IArtist;
import Act.IChef;
import Act.IDriver;
import Act.IWorker;

public class Multitalent extends BaseCharacter implements IChef, IWorker, IDriver, IArtist{

	public Multitalent(String nama, String deskripsi) {
		super(nama, deskripsi);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void Paint() {
		// TODO Auto-generated method stub
		System.out.println(getNama() + " can paint.");
	}

	@Override
	public void Drive() {
		// TODO Auto-generated method stub
		System.out.println(getNama() + " can drive.");
	}

	@Override
	public void Work() {
		// TODO Auto-generated method stub
		System.out.println(getNama() + " can work.");
	}

	@Override
	public void Cook() {
		// TODO Auto-generated method stub
		System.out.println(getNama() + " can cook.");
	}

	
}
