
import Act.IArtist;
import Act.IChef;
import Act.IWorker;

public class Artist extends BaseCharacter implements IArtist,IWorker,IChef{

	public Artist(String nama, String deskripsi) {
		super(nama, deskripsi);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void Paint() {
		// TODO Auto-generated method stub
		System.out.println(getNama() + " can paint.");
	}

	@Override
	public void Cook() {
		// TODO Auto-generated method stub
		System.out.println(getNama() + " can cook.");
	}

	@Override
	public void Work() {
		// TODO Auto-generated method stub
		System.out.println(getNama() + " can work.");
		
	}

	
}
